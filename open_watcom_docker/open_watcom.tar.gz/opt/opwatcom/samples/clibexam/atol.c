#include <stdlib.h>

void main()
  {
    long int x;

    x = atol( "-289" );
  }
