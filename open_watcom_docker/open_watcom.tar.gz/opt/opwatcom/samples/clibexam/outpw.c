#include <conio.h>
#define DEVICE 34

void main()
  {
    outpw( DEVICE, 0x1234 );
  }
