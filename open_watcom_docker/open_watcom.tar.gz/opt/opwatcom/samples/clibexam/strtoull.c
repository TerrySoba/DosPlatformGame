#include <stdlib.h>

void main()
{
    unsigned long long int v;

    v = strtoull( "12345678909876", NULL, 10 );
}
