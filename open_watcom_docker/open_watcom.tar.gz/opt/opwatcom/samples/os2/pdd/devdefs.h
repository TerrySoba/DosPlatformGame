#include <os2def.h>
#include <bsedos.h>

typedef VOID NEAR * NPVOID;
