typedef struct _TIMESTAMP
{
    ULONG   millisecs;
    ULONG   nanosecs;
    USHORT  version;
    USHORT  revision;

} TIMESTAMP, *PTIMESTAMP;
