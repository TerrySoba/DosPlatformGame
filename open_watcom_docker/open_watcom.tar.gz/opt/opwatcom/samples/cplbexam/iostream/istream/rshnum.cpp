#include <iostream.h>

void main( void ) {

    int      a;
    float    b;

    cout << "Enter an integer (decimal number): " << endl;
    cin >> a;
    cout << a << endl;
    cout << "Enter an float-point value (decimal number): " << endl;
    cin >> b;
    cout << b << endl;
}
