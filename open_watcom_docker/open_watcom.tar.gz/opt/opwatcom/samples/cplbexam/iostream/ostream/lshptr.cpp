#include <iostream.h>

void main( void ) {

    void     *ptr1, *ptr2;

    cout << "The first pointer value: " << ptr1 << endl;
    cout << "The second pointer value: " << ptr2 << endl;
}
