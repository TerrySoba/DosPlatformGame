#include <iostream.h>

void main( void ) {

    char    *pch;
    int      len = 5;

    pch = "Hello, my world!";
    cout.write( pch, len );
}
