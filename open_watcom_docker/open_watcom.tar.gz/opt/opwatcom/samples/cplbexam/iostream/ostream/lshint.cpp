#include <iostream.h>

void main( void ) {

    int    num = 12345;

    cout << num << endl;
}
