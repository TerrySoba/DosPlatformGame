#include <iostream.h>

void main( void ) {

    float    num = 123.456;

    cout << num << endl;
}
