#include <iostream.h>

void main( void ) {

    ostream    test ( 0 );
    test = cout;
    test << "Hello my world!" << endl;
}

