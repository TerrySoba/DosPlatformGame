#include <iostream.h>

void main( void ) {

    char    *c = "Open Watcom C/C++ compiler.\0";

    cout << c << endl;
}
