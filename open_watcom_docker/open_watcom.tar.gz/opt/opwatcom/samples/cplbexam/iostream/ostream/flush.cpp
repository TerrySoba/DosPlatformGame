#include <iostream.h>

void main( void ) {

    cout << "Hello, my world!";
    cout.flush();
}
