#include <string.hpp>

void main( void ) {

    String    s ('W');

    cout << "The string contains only one character '" << s << "'" << endl;
}
