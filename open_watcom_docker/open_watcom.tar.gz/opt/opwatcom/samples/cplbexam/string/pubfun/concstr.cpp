#include <string.hpp>

void main( void ) {

    char     *pch = "Open Watcom C++";
    String    s (pch);

    cout << "The string is \"" << s << "\"" << endl;
}
