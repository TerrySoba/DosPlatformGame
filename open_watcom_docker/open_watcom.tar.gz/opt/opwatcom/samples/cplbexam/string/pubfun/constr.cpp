#include <string.hpp>

void main( void ) {

    String    s ("Open Watcom C++");

    cout << "The string is \"" << s << "\"" << endl;
}

