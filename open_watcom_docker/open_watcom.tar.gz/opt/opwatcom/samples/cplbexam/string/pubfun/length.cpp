#include <string.hpp>

void main( void ) {

    String    s ("Open Watcom C++");

    cout << "The length of the string \"" << s << "\" = "
         << s.length() << endl;
}
