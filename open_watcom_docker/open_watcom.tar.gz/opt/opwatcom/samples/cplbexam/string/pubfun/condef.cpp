#include <string.hpp>

void main( void ) {

    String    s;                   // construct a default string object

    s = "Open Watcom C++";
    cout << "The string is \"" << s << "\"" << endl;
}

