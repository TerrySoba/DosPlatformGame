#include <complex.h>

void main( void ) {

    Complex     a (34.2, 24.3);

    cout << "a = " << a  << endl;
}
