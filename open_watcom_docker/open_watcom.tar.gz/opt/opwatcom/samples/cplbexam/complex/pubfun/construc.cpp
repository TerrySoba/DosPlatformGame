#include <complex.h>

void main( void ) {

    Complex    p, q (23.4, 26.7);  // construct a complex object by different
    Complex    r (q);              // syntax

    cout << p << endl;
    cout << q << endl;
    cout << r << endl;
}

