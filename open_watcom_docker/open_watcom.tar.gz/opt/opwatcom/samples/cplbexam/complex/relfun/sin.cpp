#include <complex.h>

void main( void ) {

    Complex    a (24, 27);

    cout << "The sine of " << a << " = "
         << sin( a ) << endl;
}
