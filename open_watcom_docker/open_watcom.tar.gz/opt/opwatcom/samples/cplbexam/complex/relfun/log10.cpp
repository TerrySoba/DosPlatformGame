#include <complex.h>

void main( void ) {

    Complex    a (24, 27);

    cout << "The base 10 logarithm of " << a << " = "
         << log10( a ) << endl;
}
