extern void *UtilMalloc(unsigned long );
extern void UtilFree(void *);
