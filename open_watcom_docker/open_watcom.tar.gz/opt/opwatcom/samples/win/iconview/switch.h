#define IDLISTBOX       100

extern int _EXPORT FAR PASCAL SwitchDialogProc(HWND,UINT,WPARAM,LPARAM);
extern int SwitchIcon(an_MDI_icon *);
