#define MENU_ABOUT              1
#define MENU_DIALOG             2


#define STR_LIST_1_START        1
#define STR_LIST_1_2            2
#define STR_LIST_1_3            3
#define STR_LIST_1_END          4
#define STR_LIST_2_START        5
#define STR_LIST_2_1            6
#define STR_LIST_2_END          7

#ifdef __WINDOWS_386__
#define _EXPORT
#else
#define _EXPORT __export
#endif
