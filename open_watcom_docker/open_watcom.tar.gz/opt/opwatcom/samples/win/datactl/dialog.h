
#define DLG_LIST_1                  101
#define DLG_RADIO_START             102
#define DLG_RADIO_MIDDLE            103
#define DLG_RADIO_END               104
#define DLG_TEXT                    105
#define DLG_LIST_3                  107
#define DLG_LIST_2                  108
#define DLG_NUMBER                  109
#define DLG_CHECK                   111
#define DLG_RANGE_VALUE             112
#define DLG_RANGE_NUM               113
#define DLG_VALUE                   114
