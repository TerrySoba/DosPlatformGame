extern HPALETTE CreateDIBPalette( BITMAPINFO * );
